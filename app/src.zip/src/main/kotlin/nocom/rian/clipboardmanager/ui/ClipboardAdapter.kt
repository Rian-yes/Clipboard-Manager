package nocom.rian.clipboardmanager.ui

import nocom.rian.clipboardmanager.R
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import nocom.rian.clipboardmanager.databinding.ItemClipboardBinding
import nocom.rian.clipboardmanager.db.ClipboardItem
import androidx.core.content.ContextCompat
import com.google.android.material.color.MaterialColors

data class ClipDisplayConfig(
    val showAppName: Boolean = true,
    val showPackageName: Boolean = true,
    val showWindowLabel: Boolean = true,
    val showActivityName: Boolean = true,
    val showLabel: Boolean = true,
    val showTechnicalDetails: Boolean = true
)

class ClipboardAdapter(
    private val onPinClick: (ClipboardItem) -> Unit,
    private val onExpandClick: (Int) -> Unit,
    private val onLongClick: (ClipboardItem) -> Unit,
    private val onDeleteClick: (ClipboardItem) -> Unit,
    private val onCopyClick: (ClipboardItem) -> Unit,
    private val onFavoriteClick: (ClipboardItem) -> Unit,
    private val onSensitiveClick: (ClipboardItem) -> Unit,
    private val onLabelEditClick: (ClipboardItem) -> Unit,
    private val onRevealClick: (Int) -> Unit,
    private val onEditClick: (ClipboardItem) -> Unit       // ← new
) : ListAdapter<ClipboardItem, ClipboardAdapter.ClipboardViewHolder>(DiffCallback) {

    private var expandedIds: Set<Int> = emptySet()
    private val pendingAnimationIds: MutableSet<Int> = mutableSetOf() // ← add this

    fun setExpandedIds(ids: Set<Int>) {
        val oldIds = expandedIds
        expandedIds = ids
        val changed = (oldIds - ids) + (ids - oldIds)
        pendingAnimationIds.addAll(changed)          // only expansion changes queue animation
        currentList.forEachIndexed { index, item ->
            if (changed.contains(item.id)) notifyItemChanged(index)
        }
    }
    
    private var revealedIds: Set<Int> = emptySet()
    
    fun setRevealedIds(ids: Set<Int>) {
        val oldIds = revealedIds
        revealedIds = ids
        val changed = (oldIds - ids) + (ids - oldIds)
        currentList.forEachIndexed { index, item ->
            if (changed.contains(item.id)) notifyItemChanged(index)
        }
    }
    
    private var selectedIds: Set<Int> = emptySet()

    fun setSelectedIds(ids: Set<Int>) {
        val oldIds = selectedIds
        selectedIds = ids
        val changed = (oldIds - ids) + (ids - oldIds)
        currentList.forEachIndexed { index, item ->
            if (changed.contains(item.id)) notifyItemChanged(index)
        }
    }
    
    private var displayConfig: ClipDisplayConfig = ClipDisplayConfig()

    fun setDisplayConfig(config: ClipDisplayConfig) {
        if (config == displayConfig) return
        displayConfig = config
        notifyDataSetChanged()
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClipboardViewHolder {
        val binding = ItemClipboardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ClipboardViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ClipboardViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
    
    private fun animateExpansion(view: View, expand: Boolean) {
        // Cancel any running animator stored as a tag
        (view.tag as? android.animation.ValueAnimator)?.cancel()
    
        if (expand) {
            view.visibility = View.VISIBLE
            // Measure the real target height
            view.measure(
                View.MeasureSpec.makeMeasureSpec((view.parent as View).width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val targetHeight = view.measuredHeight
            view.layoutParams.height = 0
            view.requestLayout()
    
            android.animation.ValueAnimator.ofInt(0, targetHeight).apply {
                duration = 280
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener {
                    view.layoutParams.height = it.animatedValue as Int
                    view.requestLayout()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        // Restore wrap_content so content can reflow freely
                        view.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
                        view.tag = null
                    }
                })
                view.tag = this
                start()
            }
        } else {
            val initialHeight = view.measuredHeight
            android.animation.ValueAnimator.ofInt(initialHeight, 0).apply {
                duration = 220
                interpolator = android.view.animation.AccelerateInterpolator()
                addUpdateListener {
                    view.layoutParams.height = it.animatedValue as Int
                    view.requestLayout()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        view.visibility = View.GONE
                        view.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
                        view.tag = null
                    }
                })
                view.tag = this
                start()
            }
        }
    }
    
    private fun animateArrow(arrow: View, expand: Boolean) {
        arrow.animate()
            .rotation(if (expand) 180f else 0f)
            .setDuration(280)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()
    }
    
    inner class ClipboardViewHolder(private val binding: ItemClipboardBinding) :
        RecyclerView.ViewHolder(binding.root) {
    
        // Track state to know when to animate vs. just set
        private var currentItemId: Int = -1
        private var isCurrentlyExpanded: Boolean? = null
        
        fun bind(item: ClipboardItem) {
            val isImage           = item.mimeType?.startsWith("image/") == true
            val isExpanded        = expandedIds.contains(item.id)
            val isSelected        = selectedIds.contains(item.id)
            val shouldExpand      = isExpanded
            val isSensitiveHidden = item.isSensitive && !revealedIds.contains(item.id)
        
            val shouldAnimate = pendingAnimationIds.remove(item.id)
        
            val ctx                  = binding.root.context
            val colorOnSurface       = MaterialColors.getColor(binding.root, com.google.android.material.R.attr.colorOnSurface)
            val colorOnSurfaceVar    = MaterialColors.getColor(binding.root, com.google.android.material.R.attr.colorOnSurfaceVariant)
            val colorOutlineVariant  = MaterialColors.getColor(binding.root, com.google.android.material.R.attr.colorOutlineVariant)
            val colorPinActive       = ContextCompat.getColor(ctx, R.color.color_pin_active)
            val colorSelectionBg     = ContextCompat.getColor(ctx, R.color.color_selection_background)
            val colorSelectionStroke = ContextCompat.getColor(ctx, R.color.color_selection_stroke)
            val colorSensitiveMask   = ContextCompat.getColor(ctx, R.color.color_sensitive_masked)
        
            binding.apply {
        
                // --- 1. Content ---
                if (isSensitiveHidden) {
                    clipImage.visibility = View.GONE
                    clipText.visibility  = View.VISIBLE
                    clipText.text        = "🔒  Sensitive"
                    clipText.setTextColor(colorSensitiveMask)
                    clipText.maxLines    = 1
                    clipText.ellipsize   = null
                } else if (isImage) {
                    clipText.visibility  = View.GONE
                    clipImage.visibility = View.VISIBLE
                    loadImageSafely(clipImage, item.filePath ?: "")
                    if (shouldExpand) {
                        clipImage.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
                        clipImage.scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                    } else {
                        clipImage.layoutParams.height = 180.toPx(root.context)
                        clipImage.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    }
                } else {
                    clipImage.visibility = View.GONE
                    clipText.visibility  = View.VISIBLE
                    clipText.text        = item.clip
                    clipText.setTextColor(colorOnSurface)
                    clipText.maxLines    = if (shouldExpand) Int.MAX_VALUE else 2
                    clipText.ellipsize   = if (shouldExpand) null else android.text.TextUtils.TruncateAt.END
                }
        
                // --- 2. Meta row ---
                val typeLabel = if (isImage) "Image" else item.appName ?: "Unknown"
                metaText.text = "$typeLabel • ${item.time}"
                metaText.setTextColor(colorOnSurfaceVar)
        
                // --- 3. Detail fields (config-gated) ---
                if (displayConfig.showAppName) {
                    appNameText.visibility = View.VISIBLE
                    appNameText.text       = "App: ${item.appName ?: "Unknown"}"
                    appNameText.setTextColor(colorOnSurface)
                } else {
                    appNameText.visibility = View.GONE
                }
        
                if (displayConfig.showPackageName) {
                    fullPackageText.visibility = View.VISIBLE
                    fullPackageText.text       = "Package: ${item.packageName ?: "Unknown"}"
                    fullPackageText.setTextColor(colorOnSurfaceVar)
                } else {
                    fullPackageText.visibility = View.GONE
                }
        
                val extraText = buildString {
                    if (displayConfig.showTechnicalDetails) {
                        append("ID: ${item.id}\n")
                        append("Type: ${item.mimeType ?: "text/plain"}\n")
                        append("Date: ${item.date}\n")
                    }
                    if (displayConfig.showWindowLabel && item.windowLabel != null) {
                        append("Window: ${item.windowLabel}\n")
                    }
                    if (displayConfig.showActivityName && item.activityName != null) {
                        append("Activity: ${item.activityName}\n")
                    }
                    if (displayConfig.showLabel && item.label != null) {
                        append("Label: ${item.label}\n")
                    }
                    if (displayConfig.showTechnicalDetails) {
                        if (isImage) append("Path: ${item.filePath}")
                        else append("Timestamp: ${item.timestamp}")
                    }
                }.trimEnd()
        
                if (extraText.isBlank()) {
                    extraDetailsText.visibility = View.GONE
                } else {
                    extraDetailsText.visibility = View.VISIBLE
                    extraDetailsText.text       = extraText
                    extraDetailsText.setTextColor(colorOnSurfaceVar)
                }
        
                // --- 4. Expansion ---
                val canExpand = shouldExpand && !isSensitiveHidden
                if (shouldAnimate) {
                    animateExpansion(detailContainer, canExpand)
                    animateArrow(expandArrow, canExpand)
                } else {
                    detailContainer.visibility = if (canExpand) View.VISIBLE else View.GONE
                    detailContainer.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    expandArrow.rotation = if (canExpand) 180f else 0f
                }
        
                // --- 5. Selection styling ---
                root.isChecked = isSelected
                root.setCardBackgroundColor(
                    if (isSelected) colorSelectionBg else android.graphics.Color.TRANSPARENT
                )
                root.strokeWidth = if (isSelected) 4 else 1
                root.strokeColor = if (isSelected) colorSelectionStroke else colorOutlineVariant
        
                // --- 6. Pin icon ---
                if (item.isPinned) {
                    pinIcon.setImageResource(R.drawable.baseline_push_pin)
                    pinIcon.setColorFilter(colorPinActive)
                } else {
                    pinIcon.setImageResource(R.drawable.outline_push_pin)
                    pinIcon.setColorFilter(colorOnSurfaceVar)
                }
        
                // --- 6b. Favourite icon ---
                favoriteIcon.setImageResource(
                    if (item.isFavorite) android.R.drawable.btn_star_big_on
                    else android.R.drawable.btn_star_big_off
                )
                favoriteIcon.setColorFilter(
                    if (item.isFavorite) colorPinActive else colorOnSurfaceVar
                )
        
                // --- 6c. Chips / label (config-gated) ---
                chipSensitive.isChecked = item.isSensitive
                if (displayConfig.showLabel) {
                    labelText.visibility    = View.VISIBLE
                    btnEditLabel.visibility = View.VISIBLE
                    labelText.text          = item.label ?: ""
                } else {
                    labelText.visibility    = View.GONE
                    btnEditLabel.visibility = View.GONE
                }
        
                // --- 6d. Eye icon ---
                if (item.isSensitive) {
                    eyeIcon.visibility = View.VISIBLE
                    if (isSensitiveHidden) {
                        eyeIcon.setImageResource(R.drawable.ic_visibility)
                        eyeIcon.setColorFilter(colorOnSurfaceVar)
                    } else {
                        eyeIcon.setImageResource(R.drawable.ic_visibility_off)
                        eyeIcon.setColorFilter(colorOnSurface)
                    }
                    eyeIcon.setOnClickListener { onRevealClick(item.id) }
                } else {
                    eyeIcon.visibility = View.GONE
                }
        
                // --- 7. Listeners ---
                root.setOnClickListener {
                    if (selectedIds.isNotEmpty()) onLongClick(item) else onExpandClick(item.id)
                }
                root.setOnLongClickListener { onLongClick(item); true }
                quickCopy.setOnClickListener    { onCopyClick(item) }
                pinIcon.setOnClickListener      { onPinClick(item) }
                favoriteIcon.setOnClickListener { onFavoriteClick(item) }
                btnDelete.setOnClickListener    { onDeleteClick(item) }
                btnEdit.setOnClickListener      { onEditClick(item) }
                btnEditLabel.setOnClickListener { onLabelEditClick(item) }
                chipSensitive.setOnClickListener { onSensitiveClick(item) }
            }
        }
        
        private fun loadImageSafely(imageView: android.widget.ImageView, filePath: String) {
            try {
                val file = java.io.File(filePath)
                if (!file.exists()) {
                    imageView.setImageDrawable(null)
                    return
                }
                // First pass: read dimensions only
                val options = android.graphics.BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                android.graphics.BitmapFactory.decodeFile(filePath, options)
        
                // Second pass: decode with sampling to avoid OOM
                options.inSampleSize = calculateInSampleSize(options, reqWidth = 800, reqHeight = 600)
                options.inJustDecodeBounds = false
        
                val bitmap = android.graphics.BitmapFactory.decodeFile(filePath, options)
                imageView.setImageBitmap(bitmap)
        
            } catch (e: Exception) {
                android.util.Log.e("ClipboardAdapter", "Failed to load image: $filePath", e)
                imageView.setImageDrawable(null)
            }
        }
        
        private fun calculateInSampleSize(
            options: android.graphics.BitmapFactory.Options,
            reqWidth: Int,
            reqHeight: Int
        ): Int {
            val height = options.outHeight
            val width  = options.outWidth
            var inSampleSize = 1
            if (height > reqHeight || width > reqWidth) {
                val halfHeight = height / 2
                val halfWidth  = width  / 2
                while (halfHeight / inSampleSize >= reqHeight
                    && halfWidth  / inSampleSize >= reqWidth) {
                    inSampleSize *= 2
                }
            }
            return inSampleSize
        }

        // Helper extension function to convert DP to Pixels accurately
        private fun Int.toPx(context: android.content.Context): Int {
            return (this * context.resources.displayMetrics.density).toInt()
        }
    }


    companion object DiffCallback : DiffUtil.ItemCallback<ClipboardItem>() {
        override fun areItemsTheSame(oldItem: ClipboardItem, newItem: ClipboardItem): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: ClipboardItem, newItem: ClipboardItem): Boolean = oldItem == newItem
    }
}
