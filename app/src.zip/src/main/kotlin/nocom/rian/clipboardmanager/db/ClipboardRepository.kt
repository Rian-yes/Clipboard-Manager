package nocom.rian.clipboardmanager.db

import kotlinx.coroutines.flow.Flow

class ClipboardRepository(private val clipboardDao: ClipboardDao) {

    val allClips: Flow<List<ClipboardItem>> = clipboardDao.getAllClips()
    val favoriteClips: Flow<List<ClipboardItem>> = clipboardDao.getFavoriteClips()

    suspend fun insert(item: ClipboardItem) = clipboardDao.insert(item)
    suspend fun update(item: ClipboardItem) = clipboardDao.update(item)
    suspend fun delete(item: ClipboardItem) = clipboardDao.delete(item)
    suspend fun count(): Int = clipboardDao.getTotalClipCount()

    suspend fun findByContent(text: String): ClipboardItem? = clipboardDao.findByContent(text)
    suspend fun findByHashAndPackage(hash: String, packageName: String): ClipboardItem? =
        clipboardDao.findByHashAndPackage(hash, packageName)

    suspend fun refreshExistingClip(id: Int, timestamp: Long) =
        clipboardDao.refreshExistingClip(id, timestamp) 

    suspend fun togglePin(item: ClipboardItem) =
        clipboardDao.updatePinStatus(item.id, !item.isPinned)

    suspend fun toggleFavorite(item: ClipboardItem) =
        clipboardDao.updateFavoriteStatus(item.id, !item.isFavorite)

    suspend fun toggleSensitive(item: ClipboardItem) =
        clipboardDao.updateSensitiveStatus(item.id, !item.isSensitive)

    suspend fun updateLabel(id: Int, label: String?) =
        clipboardDao.updateLabel(id, label)

    suspend fun clearUnpinned() = clipboardDao.clearUnpinnedHistory()

    suspend fun enforceClipCap(maxClips: Int) =
        clipboardDao.deleteOldestUnpinnedExceedingCap(maxClips)

    suspend fun deleteOlderThan(cutoffMs: Long) =
        clipboardDao.deleteClipsOlderThan(cutoffMs)
    
    suspend fun deleteAll() = clipboardDao.deleteAll()
    
    suspend fun getUnpinnedItems(): List<ClipboardItem> =
        clipboardDao.getUnpinnedItems()

    suspend fun getUnpinnedExceedingCap(keepCount: Int): List<ClipboardItem> =
        clipboardDao.getUnpinnedExceedingCap(keepCount)

    suspend fun getClipsOlderThan(cutoffMs: Long): List<ClipboardItem> =
        clipboardDao.getClipsOlderThan(cutoffMs)
        
    suspend fun getAllClips(): List<ClipboardItem> = clipboardDao.getAllClipsOnce()
}