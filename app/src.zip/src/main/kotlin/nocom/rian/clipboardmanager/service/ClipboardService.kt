package nocom.rian.clipboardmanager.service

import nocom.rian.clipboardmanager.R
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import androidx.core.app.NotificationCompat
import nocom.rian.clipboardmanager.MainActivity
import nocom.rian.clipboardmanager.SettingsActivity
import nocom.rian.clipboardmanager.db.AppDatabase
import nocom.rian.clipboardmanager.db.ClipboardItem
import nocom.rian.clipboardmanager.db.ClipboardRepository
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.ShizukuProvider
import android.content.IClipboard
import android.content.IOnPrimaryClipChangedListener
import android.app.IActivityManager
import android.content.pm.IPackageManager // Ensure this import matches your AIDL package

private data class ImageSaveResult(val filePath: String, val hash: String)

private data class ClipSource(
    val appName: String,
    val packageName: String,
    val windowLabel: String? = null,
    val activityName: String? = null
)

class ClipboardService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var clipboardService: IClipboard? = null
    private var activityManager: IActivityManager? = null
    private var iPackageManager: IPackageManager? = null
    
    private var lastCopiedText: String? = null
    private var lastTimestamp: Long = 0
    private val CHANNEL_ID = "clipboard_monitor_channel"

    private var isListenerRegistered = false
    private var isMonitoringActive = false
    private var pendingClipRead = false
    
    private val screenUnlockReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_USER_PRESENT && pendingClipRead) {
                android.util.Log.d("ClipboardService", "Screen unlocked — retrying pending clip read")
                pendingClipRead = false
                fetchAndSaveClipboard()
            }
        }
    }

    companion object {
        @Volatile var isRunning = false
    }
    
    private fun invokeDynamic(
        service: Any?, 
        methodName: String, 
        vararg preferredArgs: Any?
    ): Any? {
        if (service == null) return null
    
        val methods = service.javaClass.methods
        val targetMethod = methods.find { it.name == methodName } ?: run {
            android.util.Log.e("DynamicInvoker", "Method $methodName not found")
            return null
        }
    
        val expectedCount = targetMethod.parameterTypes.size
        
        // Create an array of arguments that matches exactly what the system wants
        val finalArgs = arrayOfNulls<Any>(expectedCount)
        
        for (i in 0 until expectedCount) {
            if (i < preferredArgs.size) {
                // Fill with your provided arguments (listener, package name, etc.)
                finalArgs[i] = preferredArgs[i]
            } else {
                // If the system wants more params than you gave (like userId or deviceId),
                // we default to 0 or null.
                val paramType = targetMethod.parameterTypes[i]
                finalArgs[i] = when {
                    paramType == Int::class.javaPrimitiveType -> 0
                    paramType == Long::class.javaPrimitiveType -> 0L
                    else -> null
                }
            }
        }
    
        return try {
            targetMethod.invoke(service, *finalArgs)
        } catch (e: Exception) {
            android.util.Log.e("DynamicInvoker", "Failed to invoke $methodName", e)
            null
        }
    }

    /**
    * Dynamically invokes an IClipboard method, auto-filling the standard
    * Android clipboard parameters (callingPackage, attributionTag, userId, deviceId)
    * regardless of which subset the current OS version's signature actually contains.
    *
    * Rules per parameter type:
    *   String  → 1st occurrence = "com.android.shell", 2nd = "clipboard"
    *   Int     → always 0  (userId / deviceId)
    *   Anything else → pulled in-order from [specialArgs]
    *             (e.g. IOnPrimaryClipChangedListener, ClipData)
    *
    * @param methodName  Exact name of the IClipboard method.
    * @param specialArgs Non-standard args (listener, ClipData, …) in the order
    *                    they appear in the target method signature.
    * @return The method's return value, or null on any failure.
    */
    private fun invokeClipboard(methodName: String, vararg specialArgs: Any?): Any? {
        val service = clipboardService ?: run {
            android.util.Log.w("ClipboardService", "invokeClipboard($methodName): service is null")
            return null
        }
    
        val method = service.javaClass.methods.find { it.name == methodName } ?: run {
            android.util.Log.w("ClipboardService", "invokeClipboard: method '$methodName' not found")
            return null
        }
    
        val builtArgs  = mutableListOf<Any?>()
        val specialQueue = ArrayDeque(specialArgs.toList())
        var stringCount = 0
    
        for (type in method.parameterTypes) {
            when {
                type == String::class.java -> {
                    builtArgs.add(if (stringCount++ == 0) "com.android.shell" else "clipboard")
                }
                type == Int::class.javaPrimitiveType || type == Integer::class.java -> {
                    builtArgs.add(0)
                }
                else -> {
                    // Pull the first queued arg whose runtime type is assignable to this param
                    val match = specialQueue.firstOrNull { arg ->
                        arg == null || type.isAssignableFrom(arg.javaClass)
                    }
                    specialQueue.remove(match)
                    builtArgs.add(match)
                }
            }
        }
    
        return try {
            method.invoke(service, *builtArgs.toTypedArray())
        } catch (e: Exception) {
            android.util.Log.e("ClipboardService", "invokeClipboard($methodName) failed", e)
            null
        }
    }

    private val shizukuBinderDeadListener = Shizuku.OnBinderDeadListener {
        android.util.Log.w("ClipboardService", "Shizuku binder died — clearing services")
        // Dispatch to IO — teardown makes synchronous IPC calls that must NOT run on main thread
        serviceScope.launch(Dispatchers.IO) {
            teardownShizukuServices()
        }
    }
    
    private val shizukuBinderReceivedListener = Shizuku.OnBinderReceivedListener {
        android.util.Log.d("ClipboardService", "Shizuku binder restored — reconnecting")
        serviceScope.launch(Dispatchers.IO) {
            setupShizukuServices()
        }
    }
    
    // Add this — handles permission revocation when Shizuku binder stays alive
    private val shizukuPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            if (grantResult != PackageManager.PERMISSION_GRANTED) {
                android.util.Log.w("ClipboardService", "Shizuku permission revoked — tearing down")
                serviceScope.launch(Dispatchers.IO) {
                    teardownShizukuServices()
                }
            }
        }
    
    private val clipListener = object : IOnPrimaryClipChangedListener.Stub() {
        override fun dispatchPrimaryClipChanged() {
            // This runs on a system Binder thread. An uncaught Throwable here
            // will kill the process before logcat has time to flush — hence the
            // Throwable (not Exception) catch and the explicit permission guard.
            try {
                if (!isShizukuAvailable()) {
                    android.util.Log.w("ClipboardService", "Permission lost — triggering teardown from callback")
                    serviceScope.launch(Dispatchers.IO) { teardownShizukuServices() }
                    return
                }
                fetchAndSaveClipboard()
            } catch (e: Throwable) {
                android.util.Log.e("ClipboardService", "dispatchPrimaryClipChanged crashed", e)
            }
        }
    }
    
    override fun onCreate() {
        super.onCreate()
        isRunning = true
    
        // Install BEFORE anything else — catches crashes on all threads (including
        // Binder pool threads) where logcat never flushes before process death.
//        val crashFile = java.io.File(filesDir, "last_crash.txt")
//        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
//        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
//            try {
//                val sb = StringBuilder()
//                sb.appendLine("=== CRASH REPORT ===")
//                sb.appendLine("Time:   ${java.util.Date()}")
//                sb.appendLine("Thread: ${thread.name} (id=${thread.id})")
//                sb.appendLine("isRunning=$isRunning  isMonitoringActive=$isMonitoringActive  isListenerRegistered=$isListenerRegistered")
//                sb.appendLine()
//                sb.appendLine(android.util.Log.getStackTraceString(throwable))
//                crashFile.writeText(sb.toString())
//                // Best-effort logcat write — may not flush, but worth trying
//                android.util.Log.e("ClipboardCrash", sb.toString())
//            } catch (_: Exception) {}
//            previousHandler?.uncaughtException(thread, throwable)
//        }
    
        Shizuku.addBinderDeadListener(shizukuBinderDeadListener)
        Shizuku.addBinderReceivedListener(shizukuBinderReceivedListener)
        Shizuku.addRequestPermissionResultListener(shizukuPermissionResultListener)
        val filter = android.content.IntentFilter(Intent.ACTION_USER_PRESENT)
        registerReceiver(screenUnlockReceiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(1, createNotification())
        updateNotification()
    
        if (clipboardService == null && Shizuku.pingBinder()) {
            setupShizukuServices()
        }
    
        // Run auto-delete once on service start so stale clips are cleaned immediately
        serviceScope.launch {
            val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val days = prefs.getInt(SettingsActivity.KEY_AUTO_DELETE_DAYS, 0)
            if (days > 0) {
                val cutoff = System.currentTimeMillis() - (days * 24L * 60 * 60 * 1000)
                val repository = ClipboardRepository(AppDatabase.getDatabase(applicationContext).clipboardDao())
                repository.deleteOlderThan(cutoff)
                android.util.Log.d("ClipboardService", "Auto-delete on start: removed clips older than $days days")
            }
        }
    
        return START_STICKY
    }
    
    private fun isBinderAlive(): Boolean {
        return try {
            clipboardService?.asBinder()?.isBinderAlive == true
        } catch (e: Exception) {
            false
        }
    }
    
    private fun isShizukuAvailable(): Boolean {
        return try {
            // Use the Shizuku imports already present in your file
            if (Shizuku.pingBinder()) {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
    
    private fun teardownShizukuServices() {
        try {
            if (isListenerRegistered) {
                invokeClipboard("removePrimaryClipChangedListener", clipListener)
            }
        } catch (e: Exception) {
            android.util.Log.w("ClipboardService", "Error removing listener during teardown", e)
        } finally {
            clipboardService = null
            activityManager = null
            iPackageManager = null
            isListenerRegistered = false
            isMonitoringActive = false
        }
        // Reflect the inactive state in the notification immediately
        updateNotification()
    }
    
    private fun setupShizukuServices() {
        if (!Shizuku.pingBinder()) {
            android.util.Log.w("ClipboardService", "Shizuku not available, aborting setup")
            return
        }
    
        // Must check permission BEFORE touching any Shizuku-wrapped binder.
        // After a revocation the binder is alive but calls will be rejected.
        if (!isShizukuAvailable()) {
            android.util.Log.w("ClipboardService", "Shizuku permission not granted — aborting setup")
            return
        }
    
        if (isListenerRegistered && isBinderAlive()) {
            android.util.Log.d("ClipboardService", "Binder already alive, skipping setup")
            return
        }
    
        if (clipboardService != null && !isBinderAlive()) {
            android.util.Log.w("ClipboardService", "Stale binder detected — tearing down before reconnect")
            teardownShizukuServices()
        }
    
        try {
            val serviceManagerClass = Class.forName("android.os.ServiceManager")
            val getServiceMethod = serviceManagerClass.getMethod("getService", String::class.java)
    
            val clipBinder = getServiceMethod.invoke(null, Context.CLIPBOARD_SERVICE) as IBinder
            clipboardService = IClipboard.Stub.asInterface(ShizukuBinderWrapper(clipBinder) as IBinder)
    
            val amBinder = getServiceMethod.invoke(null, Context.ACTIVITY_SERVICE) as IBinder
            activityManager = IActivityManager.Stub.asInterface(ShizukuBinderWrapper(amBinder) as IBinder)
    
            val pmBinder = getServiceMethod.invoke(null, "package") as IBinder
            iPackageManager = IPackageManager.Stub.asInterface(ShizukuBinderWrapper(pmBinder) as IBinder)
    
            invokeClipboard("addPrimaryClipChangedListener", clipListener)
            isListenerRegistered = true
            isMonitoringActive = true
            android.util.Log.d("ClipboardService", "Shizuku services connected successfully")
    
            updateNotification()
    
        } catch (e: Exception) {
            android.util.Log.e("ClipboardService", "Setup failed", e)
            teardownShizukuServices()
        }
    }
    
    private fun getTopAppInfo(): ClipSource {
        var confirmedPackage: String? = null
    
        try {
            val sourcePackage = invokeClipboard("getPrimaryClipSource") as? String
            android.util.Log.d("ClipboardService", "getPrimaryClipSource returned: $sourcePackage")
            if (!sourcePackage.isNullOrBlank()) {
                confirmedPackage = sourcePackage
            }
        } catch (e: Exception) {
            android.util.Log.w("ClipboardService", "getPrimaryClipSource failed: ${e.message}")
        }
    
        // Strategy 2: getTasks — used for window/activity enrichment.
        // If Strategy 1 confirmed a package, we search tasks for that specific package.
        // If Strategy 1 failed, we fall back to the topmost non-system task.
        try {
            val tasks = activityManager?.getTasks(10)
    
            val topTask = if (confirmedPackage != null) {
                // Prefer the task that matches our confirmed source package
                tasks?.firstOrNull { task ->
                    val pkg = task.topActivity?.packageName ?: task.baseActivity?.packageName
                    pkg == confirmedPackage
                }
                // If confirmed package has no visible task (e.g. background service copied),
                // don't fall back — we already have the right package from Strategy 1
            } else {
                // Strategy 1 failed entirely — use foreground task as best guess
                tasks?.firstOrNull { task ->
                    val pkg = task.topActivity?.packageName ?: task.baseActivity?.packageName
                    pkg != null && !isSelfOrSystem(pkg)
                }
            }
    
            if (topTask != null) {
                val topPackage = topTask.topActivity?.packageName
                    ?: topTask.baseActivity?.packageName
                    ?: confirmedPackage
                    ?: ""
    
                val activityName = topTask.topActivity?.className
                    ?.substringAfterLast('.')
                    ?.takeIf { it.isNotBlank() }
    
                val windowLabel: String? = topTask.taskDescription?.label
                    ?.takeIf { it.isNotBlank() }
                    ?: topTask.topActivity?.let { component ->
                        try {
                            packageManager.getActivityInfo(component, 0)
                                .loadLabel(packageManager)
                                .toString()
                                .takeIf { it.isNotBlank() }
                        } catch (e: Exception) { null }
                    }
    
                val appLabel = getSafeAppLabel(topPackage)
                android.util.Log.d(
                    "ClipboardService",
                    "Source: $topPackage ($appLabel) | window: $windowLabel | activity: $activityName"
                )
                return ClipSource(
                    appName      = appLabel,
                    packageName  = topPackage,
                    windowLabel  = windowLabel,
                    activityName = activityName
                )
            }
        } catch (e: Exception) {
            android.util.Log.w("ClipboardService", "getTasks failed: ${e.javaClass.simpleName}: ${e.message}")
        }
    
        // Strategy 2 failed or found no matching task — use confirmed package from Strategy 1 if available
        if (confirmedPackage != null) {
            val label = getSafeAppLabel(confirmedPackage)
            android.util.Log.d("ClipboardService", "Enrichment unavailable, using confirmed package: $confirmedPackage")
            return ClipSource(appName = label, packageName = confirmedPackage)
        }
    
        android.util.Log.d("ClipboardService", "Source unknown, defaulting to System")
        return ClipSource(appName = "System", packageName = "android")
    }
    
    /**
    * Returns true if the package belongs to our app, a launcher, or core system,
    * so we never tag a clip with our own service or the homescreen.
    */
    private fun isSelfOrSystem(pkg: String): Boolean {
        return pkg == packageName
            || pkg == "android"
            || pkg.startsWith("com.android.systemui")
            || pkg.startsWith("com.android.launcher")
            || pkg.startsWith("com.google.android.apps.nexuslauncher")
            || pkg.startsWith("com.miui.home")
            || pkg.startsWith("com.sec.android.app.launcher")
            || pkg.contains("launcher3", ignoreCase = true)
    }

    private fun getSafeAppLabel(pkg: String): String {
        val magicFlags = 0x00000400 or 0x00002000 // MATCH_ANY_USER | MATCH_UNINSTALLED_PACKAGES
    
        // Strategy 1: Standard PackageManager (Fastest, works for most user-space apps)
        try {
            val appInfo = packageManager.getApplicationInfo(pkg, magicFlags)
            val label = packageManager.getApplicationLabel(appInfo).toString()
            if (label.isNotBlank()) return label
        } catch (e: Exception) {
            android.util.Log.w("ClipboardService", "Standard PM failed for $pkg: ${e.message}")
        }
    
        // Strategy 2: Shizuku Fallback (Uses Shell UID to bypass cross-user/system restrictions)
        if (isShizukuAvailable()) {
            try {
                val label = getLabelViaShizuku(pkg, magicFlags)
                if (!label.isNullOrBlank()) {
                    android.util.Log.i("ClipboardService", "[SUCCESS] Shizuku retrieved label for $pkg")
                    return label
                }
            } catch (e: Exception) {
                android.util.Log.w("ClipboardService", "Shizuku fallback failed for $pkg: ${e.message}")
            }
        }
    
        // Strategy 3: Final Fallback (String parsing for "com.android.settings" -> "Settings")
        return pkg.substringAfterLast(".")
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }

    private fun getLabelViaShizuku(pkg: String, flags: Int): String? {
        // If our service's iPackageManager is null/dead, try to restore it
        if (iPackageManager == null || !isBinderAlive()) {
            setupShizukuServices()
        }
    
        val pm = iPackageManager ?: return null
    
        return try {
            /**
            * Find the getApplicationInfo method. We use 'find' which returns a nullable Method?
            */
            val getAppInfoMethod = pm.javaClass.methods.find { it.name == "getApplicationInfo" }
            
            // Use .let to safely handle the nullable 'getAppInfoMethod'
            getAppInfoMethod?.let { method ->
                val appInfo = if (method.parameterTypes.getOrNull(1) == Long::class.javaPrimitiveType) {
                    method.invoke(pm, pkg, flags.toLong(), 0)
                } else {
                    method.invoke(pm, pkg, flags, 0)
                } as? android.content.pm.ApplicationInfo
    
                appInfo?.let { packageManager.getApplicationLabel(it).toString() }
            }
        } catch (e: Exception) {
            android.util.Log.e("ClipboardService", "getLabelViaShizuku reflection failed", e)
            null
        }
    }
    
    private fun loadExcludedPackages(): Set<String> {
        val json = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
            .getString(SettingsActivity.KEY_EXCLUDED_PACKAGES, null) ?: return emptySet()
        return try {
            val array = org.json.JSONArray(json)
            buildSet { for (i in 0 until array.length()) add(array.getString(i)) }
        } catch (e: Exception) {
            emptySet()
        }
    }
    
    private fun fetchAndSaveClipboard() {
        serviceScope.launch {
            try {
                val keyguardManager = getSystemService(android.app.KeyguardManager::class.java)
                if (keyguardManager.isKeyguardLocked) {
                    android.util.Log.d("ClipboardService", "Screen locked — deferring clip read until unlock")
                    pendingClipRead = true
                    return@launch
                }
    
                val clipData = invokeClipboard("getPrimaryClip") as? ClipData
                if (clipData == null || clipData.itemCount == 0) return@launch
    
                val mimeType    = clipData.description.getMimeType(0) ?: "text/plain"
                val isImage     = mimeType.startsWith("image/")
                val currentTime = System.currentTimeMillis()
    
                // ── Resolve source app once, then check exclusion ────────────
                val source = getTopAppInfo()
                val excludedPackages = loadExcludedPackages()
                if (excludedPackages.contains(source.packageName)) {
                    android.util.Log.d("ClipboardService", "Skipping clip from excluded app: ${source.packageName}")
                    return@launch
                }
    
                // ── Read logging prefs once ──────────────────────────────────
                val logPrefs    = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
                val logAppName  = logPrefs.getBoolean(SettingsActivity.KEY_LOG_FIELD_APP_NAME, true)
                val logPackage  = logPrefs.getBoolean(SettingsActivity.KEY_LOG_FIELD_PACKAGE,  true)
                val logWindow   = logPrefs.getBoolean(SettingsActivity.KEY_LOG_FIELD_WINDOW,   true)
                val logActivity = logPrefs.getBoolean(SettingsActivity.KEY_LOG_FIELD_ACTIVITY, true)
    
                if (isImage) {
                    val uri       = clipData.getItemAt(0).uri ?: return@launch
                    val uriString = uri.toString()
    
                    if (uriString == lastCopiedText && (currentTime - lastTimestamp) < 1500) {
                        android.util.Log.d("ClipboardService", "Skipped: rapid duplicate image URI")
                        return@launch
                    }
    
                    lastCopiedText = uriString
                    lastTimestamp  = currentTime
    
                    val result = saveImageFromUri(uri, mimeType, currentTime) ?: run {
                        android.util.Log.e("ClipboardService", "Image save failed, aborting insert")
                        return@launch
                    }
    
                    val repository = ClipboardRepository(AppDatabase.getDatabase(applicationContext).clipboardDao())
                    val existing   = repository.findByHashAndPackage(result.hash, source.packageName)
    
                    if (existing != null) {
                        java.io.File(result.filePath).delete()
                        repository.refreshExistingClip(id = existing.id, timestamp = currentTime)
                        android.util.Log.d("ClipboardService", "Refreshed duplicate image id=${existing.id}")
                    } else {
                        repository.insert(
                            ClipboardItem(
                                clip         = null,
                                filePath     = result.filePath,
                                mimeType     = mimeType,
                                imageHash    = result.hash,
                                appName      = if (logAppName)  source.appName      else null,
                                packageName  = if (logPackage)  source.packageName  else null,
                                windowLabel  = if (logWindow)   source.windowLabel  else null,
                                activityName = if (logActivity) source.activityName else null,
                                timestamp    = currentTime
                            )
                        )
                        android.util.Log.d("ClipboardService", "Inserted image from ${source.packageName}")
                        enforcePolicies(repository)
                    }
    
                } else {
                    val text = clipData.getItemAt(0)?.text?.toString()
                    if (text.isNullOrBlank()) return@launch
    
                    if (text == lastCopiedText && (currentTime - lastTimestamp) < 1500) {
                        android.util.Log.d("ClipboardService", "Skipped: rapid duplicate text")
                        return@launch
                    }
    
                    lastCopiedText = text
                    lastTimestamp  = currentTime
    
                    val repository = ClipboardRepository(AppDatabase.getDatabase(applicationContext).clipboardDao())
                    val existing   = repository.findByContent(text)
    
                    if (existing != null) {
                        repository.refreshExistingClip(id = existing.id, timestamp = currentTime)
                        android.util.Log.d("ClipboardService", "Refreshed existing clip id=${existing.id}")
                    } else {
                        repository.insert(
                            ClipboardItem(
                                clip         = text,
                                appName      = if (logAppName)  source.appName      else null,
                                packageName  = if (logPackage)  source.packageName  else null,
                                windowLabel  = if (logWindow)   source.windowLabel  else null,
                                activityName = if (logActivity) source.activityName else null,
                                timestamp    = currentTime
                            )
                        )
                        android.util.Log.d("ClipboardService", "Inserted text clip from ${source.packageName}")
                        enforcePolicies(repository)
                    }
                }
    
                updateNotification()
    
            } catch (e: Exception) {
                android.util.Log.e("ClipboardService", "Save failed", e)
            }
        }
    }
    
    private fun saveImageFromUri(uri: android.net.Uri, mimeType: String, timestamp: Long): ImageSaveResult? {
        return try {
            val ext = when {
                mimeType.contains("png")                               -> "png"
                mimeType.contains("jpeg") || mimeType.contains("jpg") -> "jpg"
                mimeType.contains("gif")                               -> "gif"
                mimeType.contains("webp")                              -> "webp"
                else                                                   -> "png"
            }
    
            val dir = java.io.File(getExternalFilesDir(null), "clipboard_images").also { it.mkdirs() }
            val file   = java.io.File(dir, "img_$timestamp.$ext")
            val digest = java.security.MessageDigest.getInstance("MD5")
    
            // Strategy 1: direct ContentResolver — works for MediaStore and other accessible URIs.
            val stream: java.io.InputStream? = try {
                contentResolver.openInputStream(uri)
            } catch (e: SecurityException) {
                android.util.Log.d("ClipboardService", "Direct access denied — falling back to IContentProvider via Shizuku")
                null
            }
    
            // Strategy 2: IContentProvider via ShizukuBinderWrapper (shell identity).
            val input = stream ?: openUriViaIContentProvider(uri) ?: run {
                android.util.Log.e("ClipboardService", "All open strategies failed for URI=$uri")
                return null
            }
    
            input.use { raw ->
                java.security.DigestInputStream(raw, digest).use { hashed ->
                    file.outputStream().use { out -> hashed.copyTo(out) }
                }
            }
    
            if (file.exists() && file.length() > 0) {
                val hash = digest.digest().joinToString("") { "%02x".format(it) }
                android.util.Log.d("ClipboardService", "Image saved: hash=$hash path=${file.absolutePath}")
                ImageSaveResult(file.absolutePath, hash)
            } else {
                android.util.Log.e("ClipboardService", "File empty after write — URI=$uri")
                file.delete()
                null
            }
    
        } catch (e: Exception) {
            android.util.Log.e("ClipboardService", "saveImageFromUri failed", e)
            null
        }
    }
        /**
    * Calls IActivityManager.getContentProviderExternal() through the Shizuku-wrapped
    * activityManager binder (shell uid 2000), so the system grants access to
    * non-exported FileProviders that gave their URI grant to shell.
    */
    private fun getIContentProviderBinder(authority: String): IBinder? {
        val amBinder = activityManager?.asBinder() ?: return null
    
        // Resolve the transaction code via reflection (HiddenApiBypass is already enabled)
        val transCode = try {
            Class.forName("android.app.IActivityManager\$Stub")
                .getDeclaredField("TRANSACTION_getContentProviderExternal")
                .apply { isAccessible = true }
                .getInt(null)
        } catch (e: Exception) {
            android.util.Log.e("ClipboardService", "TRANSACTION_getContentProviderExternal not found", e)
            return null
        }
    
        val data  = Parcel.obtain()
        val reply = Parcel.obtain()
        return try {
            data.writeInterfaceToken("android.app.IActivityManager")
            data.writeString(authority)   // name
            data.writeInt(0)              // userId (0 = primary user)
            data.writeStrongBinder(null)  // token
            data.writeString(authority)   // tag
    
            // This transact routes through ShizukuBinderWrapper → executes as shell uid 2000
            amBinder.transact(transCode, data, reply, 0)
            reply.readException()
    
            if (reply.readInt() == 0) {
                android.util.Log.e("ClipboardService", "getContentProviderExternal: null holder for $authority")
                return null
            }
    
            // Parse ContentProviderHolder from reply Parcel:
            //   Field 1: ProviderInfo          → skip by consuming it
            //   Field 2: IContentProvider binder
            //            API 29-30: writeInt(hasProvider=1) + writeStrongBinder
            //            API 31+:   writeStrongBinder directly (writeStrongInterface)
            //   Field 3: IBinder connection    → not needed
            //   Field 4: int noReleaseNeeded   → not needed
    
            android.content.pm.ProviderInfo.CREATOR.createFromParcel(reply) // consume ProviderInfo
    
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                reply.readStrongBinder()
            } else {
                if (reply.readInt() != 0) reply.readStrongBinder() else null
            }
    
        } catch (e: Exception) {
            android.util.Log.e("ClipboardService", "getIContentProviderBinder failed for $authority", e)
            null
        } finally {
            data.recycle()
            reply.recycle()
        }
    }
    
    /**
    * Opens a content URI as a stream using IContentProvider obtained via Shizuku.
    * Both getContentProviderExternal and openFile are performed as shell uid 2000,
    * satisfying the URI grant that was issued when the clipboard was read via Shizuku.
    */
    private fun openUriViaIContentProvider(uri: android.net.Uri): java.io.InputStream? {
        return try {
            val cmd = arrayOf("content", "read", "--uri", uri.toString())
            
            // 1. Reflect into Shizuku to access the "private" newProcess
            val shizukuClass = rikka.shizuku.Shizuku::class.java
            val newProcessMethod = shizukuClass.getDeclaredMethod(
                "newProcess", 
                Array<String>::class.java, 
                Array<String>::class.java, 
                String::class.java
            )
            newProcessMethod.isAccessible = true
    
            // 2. Invoke the process (Acting as Shell)
            val remoteProcess = newProcessMethod.invoke(null, cmd, null, null) as java.lang.Process
            val stdout = remoteProcess.inputStream
    
            // 3. Check for data
            val bis = java.io.BufferedInputStream(stdout)
            bis.mark(10)
            if (bis.read() == -1) {
                android.util.Log.e("ClipboardService", "Shell 'content read' returned no data")
                remoteProcess.destroy()
                return null
            }
            bis.reset()
            
            // Note: The process stays alive as long as you are reading the stream.
            // It will be cleaned up when you close the stream in saveImageFromUri.
            return bis
    
        } catch (e: Exception) {
            android.util.Log.e("ClipboardService", "Shizuku reflection process failed", e)
            null
        }
    }

    private fun createNotification(clipCount: Int = 0): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        )
        val contentTitle = when {
            !isMonitoringActive -> "Monitoring Stopped"
            else -> "Monitoring Clipboard"
        }
        val contentText = when {
            !isMonitoringActive -> "⚠ Shizuku disconnected"
            clipCount == 0 -> "Monitoring system clipboard..."
            else -> "$clipCount clip${if (clipCount == 1) "" else "s"} saved"
        }
    
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(contentTitle)
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_clipboard)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setShowWhen(false)
            .build()
    }
    
    private fun updateNotification() {
        serviceScope.launch(Dispatchers.IO) {
            val count = AppDatabase.getDatabase(applicationContext)
                .clipboardDao().getTotalClipCount()
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(1, createNotification(count))
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Clipboard Monitor", NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

   // Replace deleteImageFileIfNeeded entirely:
    private fun deleteImageFileIfNeeded(item: ClipboardItem) {
        if (item.mimeType?.startsWith("image/") == true) {
            val file = java.io.File(item.filePath ?: return)
            if (file.exists()) {
                val deleted = file.delete()
                android.util.Log.d("ClipboardService", "Image file deleted=$deleted: ${item.filePath}")
            }
        }
    }
    
    private suspend fun enforcePolicies(repository: ClipboardRepository) {
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
    
        val cap = prefs.getInt(SettingsActivity.KEY_CLIP_CAP, 0)
        if (cap > 0) {
            repository.getUnpinnedExceedingCap(cap).forEach { deleteImageFileIfNeeded(it) }
            repository.enforceClipCap(cap)
            android.util.Log.d("ClipboardService", "Clip cap enforced: keeping newest $cap clips")
        }
    
        val days = prefs.getInt(SettingsActivity.KEY_AUTO_DELETE_DAYS, 0)
        if (days > 0) {
            val cutoff = System.currentTimeMillis() - (days * 24L * 60 * 60 * 1000)
            repository.getClipsOlderThan(cutoff).forEach { deleteImageFileIfNeeded(it) }
            repository.deleteOlderThan(cutoff)
            android.util.Log.d("ClipboardService", "Auto-delete enforced: clips older than $days days removed")
        }
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        isRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java)?.cancel(1)
        serviceScope.cancel()
        Shizuku.removeBinderDeadListener(shizukuBinderDeadListener)
        Shizuku.removeBinderReceivedListener(shizukuBinderReceivedListener)
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionResultListener)
        teardownShizukuServices()
        try { unregisterReceiver(screenUnlockReceiver) } catch (_: Exception) {}

        super.onDestroy()
    }
}
