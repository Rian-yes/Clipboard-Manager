package nocom.rian.clipboardmanager

import android.content.pm.PackageManager
import android.app.NotificationManager
import android.os.Bundle
import android.content.Intent
import android.os.Build
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.RecyclerView
import android.view.Menu
import android.view.MenuItem
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import nocom.rian.clipboardmanager.databinding.ActivityMainBinding
import nocom.rian.clipboardmanager.service.ClipboardService
import nocom.rian.clipboardmanager.ui.ClipboardAdapter
import nocom.rian.clipboardmanager.ui.ClipboardViewModel
import nocom.rian.clipboardmanager.db.ClipboardItem
import nocom.rian.clipboardmanager.ui.ClipDisplayConfig
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuProvider

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    
    private val viewModel: ClipboardViewModel by viewModels()
    private lateinit var clipboardAdapter: ClipboardAdapter

    private var shizukuSnackbar: Snackbar? = null
    
    private val editClipLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        val data = result.data ?: return@registerForActivityResult
        val itemId = data.getIntExtra(EditClipActivity.EXTRA_ITEM_ID, -1)
        if (itemId == -1) return@registerForActivityResult
    
        viewModel.updateClipById(
            itemId        = itemId,
            newClip       = data.getStringExtra(EditClipActivity.EXTRA_CLIP_TEXT),
            newLabel      = data.getStringExtra(EditClipActivity.EXTRA_LABEL),
            newAppName    = data.getStringExtra(EditClipActivity.EXTRA_APP_NAME),
            newPackageName= data.getStringExtra(EditClipActivity.EXTRA_PACKAGE_NAME),
            newWindowLabel= data.getStringExtra(EditClipActivity.EXTRA_WINDOW_LABEL),
            newActivityName=data.getStringExtra(EditClipActivity.EXTRA_ACTIVITY_NAME)
        )
    }
    
    // Shizuku Listeners
    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                val monitoringEnabled = getSharedPreferences(
                    "clipboard_settings", android.content.Context.MODE_PRIVATE
                ).getBoolean("monitoring_enabled",true)
    
                if (monitoringEnabled) {
                    startClipboardService()
                }
            }
        } catch (e: Exception) { /* ignore */ }
    
        // Dismiss the "Shizuku not connected" snackbar if it's showing
        runOnUiThread {
            shizukuSnackbar?.dismiss()
            shizukuSnackbar = null
        }
    }
    
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        // ClipboardService handles its own reconnection; nothing to do in UI
    }
    
    private val notificationPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Proceed regardless — permission is optional, service still runs
        startClipboardServiceIfShizukuReady()
    }
    
    private fun checkForCrashLog() {
        val crashFile = java.io.File(filesDir, "last_crash.txt")
        if (!crashFile.exists()) return
    
        val report = try { crashFile.readText() } catch (_: Exception) { return }
        crashFile.delete()
    
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Previous Crash Log")
            .setMessage(report)
            .setPositiveButton("Copy") { _, _ ->
                val clipboard = getSystemService(android.content.ClipboardManager::class.java)
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("crash", report))
                Toast.makeText(this, "Crash log copied", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Dismiss", null)
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    
        setSupportActionBar(binding.toolbar)
    
        // If the service isn't running, cancel any stale notification left from a crash
        if (!ClipboardService.isRunning) {
            getSystemService(NotificationManager::class.java)?.cancel(1)
        }
        // NEW — request notification permission upfront, then start service
        requestNotificationPermissionThenStart()
        setupBackPressHandler()
        setupRecyclerView()
        setupClickListeners()
        observeViewModel()
        updateFilterIndicator()
        
        Shizuku.addBinderReceivedListener(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
    }

    override fun onResume() {
        super.onResume()
        applyManualEntryVisibility()
        checkAndShowShizukuStatus()
        clipboardAdapter.setDisplayConfig(buildDisplayConfig())
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_shizuku -> {
                startActivity(Intent(this, ShizukuActivity::class.java))
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_clear_unpinned -> {
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Clear Unpinned Clips")
                    .setMessage("Delete all unpinned clips? This cannot be undone.")
                    .setPositiveButton("Clear") { _, _ -> viewModel.deleteAllUnpinned() }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupRecyclerView() {
        clipboardAdapter = ClipboardAdapter(
            onPinClick      = { item -> viewModel.togglePin(item) },
            onExpandClick   = { id   -> viewModel.toggleExpand(id) },
            onLongClick     = { item -> viewModel.toggleSelection(item) },
            onDeleteClick   = { item -> viewModel.delete(item) },
            onCopyClick     = { item ->
                viewModel.copyToClipboard(this, item)
                val message = if (item.mimeType?.startsWith("image/") == true)
                    "Image copied to clipboard!"
                else
                    "Copied to clipboard!"
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            },
            onFavoriteClick   = { item -> viewModel.toggleFavorite(item) },
            onSensitiveClick  = { item -> viewModel.toggleSensitive(item) },
            onLabelEditClick  = { item -> showLabelDialog(item) },
            onRevealClick     = { id   -> viewModel.toggleRevealSensitive(id) },
            onEditClick       = { item -> editClipLauncher.launch(EditClipActivity.createIntent(this, item)) }
        )
    
        binding.clipboardRecycler.apply {
            adapter = clipboardAdapter
            layoutManager = LinearLayoutManager(this@MainActivity)
            setHasFixedSize(true)
            itemAnimator = DefaultItemAnimator().apply { changeDuration = 300 }
    
            clipboardAdapter.registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
                override fun onItemRangeMoved(fromPosition: Int, toPosition: Int, itemCount: Int) {
                    val lm = layoutManager as? LinearLayoutManager
                    if (fromPosition == 0 && toPosition > fromPosition) {
                        lm?.scrollToPositionWithOffset(0, 0)
                    }
                }
            })
        }
    }
    
    private fun setupClickListeners() {
        binding.btnAddClip.setOnClickListener {
            val text = binding.editClipInput.text.toString()
            if (text.isNotBlank()) {
                viewModel.insert(text)
                binding.editClipInput.text?.clear()
            }
        }
    
        binding.btnDeleteSelected.setOnClickListener {
            val count = viewModel.selectedIds.value.size
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Delete $count clip${if (count == 1) "" else "s"}?")
                .setMessage("This cannot be undone.")
                .setPositiveButton("Delete") { _, _ -> viewModel.deleteSelectedClips() }
                .setNegativeButton("Cancel", null)
                .show()
        }
        binding.btnPinSelected.setOnClickListener { viewModel.togglePinSelectedClips() }
    
        binding.btnSelectAll.setOnClickListener {
            val allIds = (viewModel.filteredClips.value ?: emptyList()).map { it.id }.toSet()
            if (viewModel.selectedIds.value == allIds) {
                viewModel.clearSelection()
            } else {
                viewModel.selectAll(viewModel.filteredClips.value ?: emptyList())
            }
        }
    
        binding.editSearchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.setSearchQuery(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    
        binding.btnFilter.setOnClickListener { showFilterBottomSheet() }
    }
    
    private fun showFilterBottomSheet() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.filter_bottom_sheet, null)
        dialog.setContentView(sheet)
    
        val searchGroup = sheet.findViewById<com.google.android.material.chip.ChipGroup>(R.id.sheetSearchFieldChipGroup)
        val filterGroup = sheet.findViewById<com.google.android.material.chip.ChipGroup>(R.id.sheetFilterChipGroup)
        val sortGroup   = sheet.findViewById<com.google.android.material.chip.ChipGroup>(R.id.sheetSortChipGroup)
    
        // Pre-select chips to match current ViewModel state
        sheet.findViewById<com.google.android.material.chip.Chip>(
            when (viewModel.searchField.value) {
                ClipboardViewModel.SearchField.CONTENT  -> R.id.sheetChipSearchContent
                ClipboardViewModel.SearchField.APP_NAME -> R.id.sheetChipSearchApp
                ClipboardViewModel.SearchField.LABEL    -> R.id.sheetChipSearchLabel
                ClipboardViewModel.SearchField.PACKAGE  -> R.id.sheetChipSearchPackage
                ClipboardViewModel.SearchField.WINDOW   -> R.id.sheetChipSearchWindow
                ClipboardViewModel.SearchField.ACTIVITY -> R.id.sheetChipSearchActivity
                else                                    -> R.id.sheetChipSearchAll
            }
        ).isChecked = true
    
        sheet.findViewById<com.google.android.material.chip.Chip>(
            when (viewModel.activeFilter.value) {
                ClipboardViewModel.Filter.SENSITIVE -> R.id.sheetChipFilterSensitive
                ClipboardViewModel.Filter.PINNED    -> R.id.sheetChipFilterPinned
                ClipboardViewModel.Filter.FAVORITES -> R.id.sheetChipFilterFavorites
                ClipboardViewModel.Filter.IMAGES    -> R.id.sheetChipFilterImages
                else                                -> R.id.sheetChipFilterAll
            }
        ).isChecked = true
    
        sheet.findViewById<com.google.android.material.chip.Chip>(
            when (viewModel.sortOrder.value) {
                ClipboardViewModel.SortOrder.OLDEST    -> R.id.sheetChipSortOldest
                ClipboardViewModel.SortOrder.LAST_USED -> R.id.sheetChipSortLastUsed
                ClipboardViewModel.SortOrder.ALPHA     -> R.id.sheetChipSortAlpha
                ClipboardViewModel.SortOrder.ALPHA_APP -> R.id.sheetChipSortAlphaApp
                ClipboardViewModel.SortOrder.TYPE      -> R.id.sheetChipSortType
                else                                   -> R.id.sheetChipSortNewest
            }
        ).isChecked = true
    
        // Live-apply each group on change
        searchGroup.setOnCheckedStateChangeListener { _, ids ->
            viewModel.setSearchField(when (ids.firstOrNull()) {
                R.id.sheetChipSearchContent  -> ClipboardViewModel.SearchField.CONTENT
                R.id.sheetChipSearchApp      -> ClipboardViewModel.SearchField.APP_NAME
                R.id.sheetChipSearchLabel    -> ClipboardViewModel.SearchField.LABEL
                R.id.sheetChipSearchPackage  -> ClipboardViewModel.SearchField.PACKAGE
                R.id.sheetChipSearchWindow   -> ClipboardViewModel.SearchField.WINDOW
                R.id.sheetChipSearchActivity -> ClipboardViewModel.SearchField.ACTIVITY
                else                         -> ClipboardViewModel.SearchField.ALL
            })
            updateFilterIndicator()
        }
    
        filterGroup.setOnCheckedStateChangeListener { _, ids ->
            viewModel.setFilter(when (ids.firstOrNull()) {
                R.id.sheetChipFilterSensitive -> ClipboardViewModel.Filter.SENSITIVE
                R.id.sheetChipFilterPinned    -> ClipboardViewModel.Filter.PINNED
                R.id.sheetChipFilterFavorites -> ClipboardViewModel.Filter.FAVORITES
                R.id.sheetChipFilterImages    -> ClipboardViewModel.Filter.IMAGES
                else                          -> ClipboardViewModel.Filter.ALL
            })
            updateFilterIndicator()
        }
    
        sortGroup.setOnCheckedStateChangeListener { _, ids ->
            viewModel.setSortOrder(when (ids.firstOrNull()) {
                R.id.sheetChipSortOldest   -> ClipboardViewModel.SortOrder.OLDEST
                R.id.sheetChipSortLastUsed -> ClipboardViewModel.SortOrder.LAST_USED
                R.id.sheetChipSortAlpha    -> ClipboardViewModel.SortOrder.ALPHA
                R.id.sheetChipSortAlphaApp -> ClipboardViewModel.SortOrder.ALPHA_APP
                R.id.sheetChipSortType     -> ClipboardViewModel.SortOrder.TYPE
                else                       -> ClipboardViewModel.SortOrder.NEWEST
            })
            updateFilterIndicator()
        }
    
        sheet.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnResetFilters)
            .setOnClickListener {
                viewModel.setFilter(ClipboardViewModel.Filter.ALL)
                viewModel.setSearchField(ClipboardViewModel.SearchField.ALL)
                viewModel.setSortOrder(ClipboardViewModel.SortOrder.NEWEST)
                sheet.findViewById<com.google.android.material.chip.Chip>(R.id.sheetChipSearchAll).isChecked = true
                sheet.findViewById<com.google.android.material.chip.Chip>(R.id.sheetChipFilterAll).isChecked = true
                sheet.findViewById<com.google.android.material.chip.Chip>(R.id.sheetChipSortNewest).isChecked = true
                updateFilterIndicator()
            }
    
        sheet.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnApplyFilters)
            .setOnClickListener { dialog.dismiss() }
    
        dialog.show()
    }
    
    private fun updateFilterIndicator() {
        val filterLabel = when (viewModel.activeFilter.value) {
            ClipboardViewModel.Filter.SENSITIVE -> "Sensitive"
            ClipboardViewModel.Filter.PINNED    -> "Pinned"
            ClipboardViewModel.Filter.FAVORITES -> "Favorites"
            ClipboardViewModel.Filter.IMAGES    -> "Images"
            ClipboardViewModel.Filter.ALL       -> "All clips"
        }
        val sortLabel = when (viewModel.sortOrder.value) {
            ClipboardViewModel.SortOrder.OLDEST    -> "Oldest"
            ClipboardViewModel.SortOrder.LAST_USED -> "Last Used"
            ClipboardViewModel.SortOrder.ALPHA     -> "A→Z Content"
            ClipboardViewModel.SortOrder.ALPHA_APP -> "A→Z App"
            ClipboardViewModel.SortOrder.TYPE      -> "Type"
            ClipboardViewModel.SortOrder.NEWEST    -> "Newest"
        }
        val fieldSuffix = when (viewModel.searchField.value) {
            ClipboardViewModel.SearchField.CONTENT  -> " · Content"
            ClipboardViewModel.SearchField.APP_NAME -> " · App"
            ClipboardViewModel.SearchField.LABEL    -> " · Label"
            ClipboardViewModel.SearchField.PACKAGE  -> " · Package"
            ClipboardViewModel.SearchField.WINDOW   -> " · Window"
            ClipboardViewModel.SearchField.ACTIVITY -> " · Activity"
            else                                    -> ""
        }
        binding.tvActiveFilters.text = "$filterLabel · $sortLabel$fieldSuffix"
    
        val isFiltered = viewModel.activeFilter.value != ClipboardViewModel.Filter.ALL
            || viewModel.sortOrder.value != ClipboardViewModel.SortOrder.NEWEST
            || viewModel.searchField.value != ClipboardViewModel.SearchField.ALL
        binding.btnFilter.alpha = if (isFiltered) 1.0f else 0.75f
    }
    
    private var previousClipCount = 0

    private fun observeViewModel() {
        viewModel.filteredClips.observe(this) { clips ->
            clips?.let { list ->
                val isNewItemAdded = list.size > previousClipCount
                previousClipCount = list.size
    
                binding.emptyStateView.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    
                clipboardAdapter.submitList(list) {
                    if (isNewItemAdded) binding.clipboardRecycler.scrollToPosition(0)
                }
            }
        }
    
        lifecycleScope.launch {
            viewModel.selectedIds.collect { ids ->
                clipboardAdapter.setSelectedIds(ids)
        
                val count = ids.size
                val selectedItems = (viewModel.filteredClips.value ?: emptyList())
                    .filter { ids.contains(it.id) }
                val allPinned = selectedItems.isNotEmpty() && selectedItems.all { it.isPinned }
        
                binding.btnPinSelected.text    = if (allPinned) "Unpin $count items" else "Pin $count items"
                binding.btnDeleteSelected.text = "Delete $count items"
        
                val totalVisible = viewModel.filteredClips.value?.size ?: 0
                binding.btnSelectAll.text = if (ids.size == totalVisible && totalVisible > 0)
                    "Deselect All" else "Select All"
            }
        }
    
        lifecycleScope.launch {
            viewModel.expandedIds.collect { ids ->
                clipboardAdapter.setExpandedIds(ids)
            }
        }
    
        lifecycleScope.launch {
            viewModel.isSelectionMode.collect { isInSelectionMode ->
                binding.btnDeleteSelected.visibility = if (isInSelectionMode) View.VISIBLE else View.GONE
                binding.btnPinSelected.visibility    = if (isInSelectionMode) View.VISIBLE else View.GONE
                binding.selectAllLayout.visibility   = if (isInSelectionMode) View.VISIBLE else View.GONE
            }
        }
        
        lifecycleScope.launch {
            viewModel.revealedSensitiveIds.collect { ids ->
                clipboardAdapter.setRevealedIds(ids)
            }
        }
    }
    
    private fun startClipboardService() {
        val intent = Intent(this, ClipboardService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
    
    private fun startClipboardServiceIfShizukuReady() {
        try {
            if (Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                val monitoringEnabled = getSharedPreferences(
                    "clipboard_settings", android.content.Context.MODE_PRIVATE
                ).getBoolean("monitoring_enabled",true)
    
                if (monitoringEnabled) {
                    startClipboardService()
                }
            }
        } catch (e: Exception) { /* ignore */ }
    }
    
    private fun applyManualEntryVisibility() {
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE)
        val show = prefs.getBoolean(SettingsActivity.KEY_SHOW_MANUAL_ENTRY, true)
        binding.manualEntryLayout.visibility = if (show) View.VISIBLE else View.GONE
    }
    
    private fun checkAndShowShizukuStatus() {
        val isConnected = try {
            Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    
        if (!isConnected) {
            shizukuSnackbar = Snackbar.make(
                binding.root,
                "Shizuku is not connected — clipboard monitoring is inactive",
                Snackbar.LENGTH_INDEFINITE
            )
            .setAction("Fix") {
                startActivity(Intent(this, ShizukuActivity::class.java))
            }
            .also { it.show() }
        } else {
            shizukuSnackbar?.dismiss()
            shizukuSnackbar = null
        }
    }
    
    private fun setupBackPressHandler() {
        onBackPressedDispatcher.addCallback(
            this,
            object : androidx.activity.OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (viewModel.isSelectionMode.value) {
                        viewModel.clearSelection()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        )
    }
        
//    private fun requestBatteryOptimizationExemption() {
//        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
//    
//        val pm = getSystemService(android.os.PowerManager::class.java)
//        if (pm.isIgnoringBatteryOptimizations(packageName)) {
//            android.util.Log.d("MainActivity", "Already exempt from battery optimization")
//            return
//        }
//    
//        try {
//            val intent = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
//                data = android.net.Uri.parse("package:$packageName")
//            }
//            startActivity(intent)
//        } catch (e: Exception) {
//            // Fallback: send user to general battery settings if the direct intent isn't available
//            android.util.Log.w("MainActivity", "Direct battery exemption intent unavailable", e)
//            try {
//                startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
//            } catch (e2: Exception) {
//                android.util.Log.e("MainActivity", "Battery settings unavailable", e2)
//            }
//        }
//    }
    
    private fun requestNotificationPermissionThenStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            // Show the system permission dialog immediately on launch
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            // Already granted (or pre-13) — go straight to starting the service
            startClipboardServiceIfShizukuReady()
        }
    }
    
    private fun showLabelDialog(item: ClipboardItem) {
        val input = android.widget.EditText(this).apply {
            setText(item.label)
            hint = "Enter a label..."
            setPadding(48, 24, 48, 24)
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Edit Label")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val label = input.text.toString().trim().ifBlank { null }
                viewModel.updateLabel(item, label)
            }
            .setNegativeButton("Clear") { _, _ -> viewModel.updateLabel(item, null) }
            .setNeutralButton("Cancel", null)
            .show()
    }
    
    private fun buildDisplayConfig(): ClipDisplayConfig {
        val p = getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE)
        return ClipDisplayConfig(
            showAppName          = p.getBoolean(SettingsActivity.KEY_SHOW_FIELD_APP_NAME, true),
            showPackageName      = p.getBoolean(SettingsActivity.KEY_SHOW_FIELD_PACKAGE,  true),
            showWindowLabel      = p.getBoolean(SettingsActivity.KEY_SHOW_FIELD_WINDOW,   true),
            showActivityName     = p.getBoolean(SettingsActivity.KEY_SHOW_FIELD_ACTIVITY, true),
            showLabel            = p.getBoolean(SettingsActivity.KEY_SHOW_FIELD_LABEL,    true),
            showTechnicalDetails = p.getBoolean(SettingsActivity.KEY_SHOW_FIELD_TECH,     true)
        )
    }
    
    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
    }
}
