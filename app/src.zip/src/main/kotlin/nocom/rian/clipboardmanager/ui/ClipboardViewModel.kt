package nocom.rian.clipboardmanager.ui

import android.app.Application
import androidx.lifecycle.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import nocom.rian.clipboardmanager.db.AppDatabase
import nocom.rian.clipboardmanager.db.ClipboardItem
import nocom.rian.clipboardmanager.db.ClipboardRepository

class ClipboardViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ClipboardRepository
    val allClips: LiveData<List<ClipboardItem>>
    val filteredClips: LiveData<List<ClipboardItem>>

    private val _expandedIds = MutableStateFlow<Set<Int>>(emptySet())
    val expandedIds: StateFlow<Set<Int>> = _expandedIds

    private val _selectedIds = MutableStateFlow<Set<Int>>(emptySet())
    val selectedIds: StateFlow<Set<Int>> = _selectedIds

    private val _isSelectionMode = MutableStateFlow(false)
    val isSelectionMode: StateFlow<Boolean> = _isSelectionMode

    fun selectAll(clips: List<ClipboardItem>) {
        _selectedIds.value = clips.map { it.id }.toSet()
        _isSelectionMode.value = _selectedIds.value.isNotEmpty()
    }
    
    private val _revealedSensitiveIds = MutableStateFlow<Set<Int>>(emptySet())
    val revealedSensitiveIds: StateFlow<Set<Int>> = _revealedSensitiveIds
    
    fun toggleRevealSensitive(itemId: Int) {
        val current = _revealedSensitiveIds.value
        _revealedSensitiveIds.value = if (current.contains(itemId)) current - itemId else current + itemId
    }
    
    private val _searchQuery = MutableStateFlow("")

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }
    
    enum class Filter { ALL, PINNED, FAVORITES, IMAGES, SENSITIVE }
    private val _activeFilter = MutableStateFlow(Filter.ALL)
    val activeFilter: StateFlow<Filter> = _activeFilter
    fun setFilter(filter: Filter) { _activeFilter.value = filter }
    
    enum class SearchField { ALL, CONTENT, APP_NAME, LABEL, PACKAGE, WINDOW, ACTIVITY }
    private val _searchField = MutableStateFlow(SearchField.ALL)
    val searchField: StateFlow<SearchField> = _searchField
    fun setSearchField(field: SearchField) { _searchField.value = field }
    
    enum class SortOrder { NEWEST, OLDEST, LAST_USED, ALPHA, ALPHA_APP, TYPE }
    private val _sortOrder = MutableStateFlow(SortOrder.NEWEST)
    val sortOrder: StateFlow<SortOrder> = _sortOrder
    fun setSortOrder(order: SortOrder) { _sortOrder.value = order }
    
    private var cachedClips: List<ClipboardItem> = emptyList()

    init {
        val dao = AppDatabase.getDatabase(application).clipboardDao()
        repository = ClipboardRepository(dao)
        allClips = repository.allClips.asLiveData()
    
        // Cache always-fresh list for operations that can't use LiveData.value safely
        viewModelScope.launch {
            repository.allClips.collect { cachedClips = it }
        }
    
        filteredClips = combine(
            repository.allClips,
            _searchQuery,
            _activeFilter,
            _searchField,
            _sortOrder
        ) { clips, query, filter, searchField, sortOrder ->
        
            // Step 1: apply category filter
            val base = when (filter) {
                Filter.SENSITIVE -> clips.filter { it.isSensitive }
                Filter.PINNED    -> clips.filter { it.isPinned }
                Filter.FAVORITES -> clips.filter { it.isFavorite }
                Filter.IMAGES    -> clips.filter { it.mimeType?.startsWith("image/") == true }
                Filter.ALL       -> clips
            }
        
            // Step 2: apply search with field scoping
            val searched = if (query.isBlank()) base else base.filter { item ->
                when (searchField) {
                    SearchField.ALL      ->
                        item.clip?.contains(query, ignoreCase = true) == true ||
                        item.appName?.contains(query, ignoreCase = true) == true ||
                        item.label?.contains(query, ignoreCase = true) == true ||
                        item.packageName?.contains(query, ignoreCase = true) == true ||
                        item.windowLabel?.contains(query, ignoreCase = true) == true ||
                        item.activityName?.contains(query, ignoreCase = true) == true
                    SearchField.CONTENT  ->
                        item.clip?.contains(query, ignoreCase = true) == true
                    SearchField.APP_NAME ->
                        item.appName?.contains(query, ignoreCase = true) == true
                    SearchField.LABEL    ->
                        item.label?.contains(query, ignoreCase = true) == true
                    SearchField.PACKAGE  ->
                        item.packageName?.contains(query, ignoreCase = true) == true
                    SearchField.WINDOW   ->
                        item.windowLabel?.contains(query, ignoreCase = true) == true
                    SearchField.ACTIVITY ->
                        item.activityName?.contains(query, ignoreCase = true) == true
                }
            }
        
            // Step 3: apply sort — pinned items always float to top
            when (sortOrder) {
                SortOrder.NEWEST    ->
                    searched.sortedWith(compareByDescending<ClipboardItem> { it.isPinned }
                        .thenByDescending { it.timestamp })
                SortOrder.OLDEST    ->
                    searched.sortedWith(compareByDescending<ClipboardItem> { it.isPinned }
                        .thenBy { it.timestamp })
                SortOrder.LAST_USED ->
                    searched.sortedWith(compareByDescending<ClipboardItem> { it.isPinned }
                        .thenByDescending { it.timestamp })
                SortOrder.ALPHA     ->
                    searched.sortedWith(compareByDescending<ClipboardItem> { it.isPinned }
                        .thenBy { (it.clip ?: it.appName ?: "").lowercase() })
                SortOrder.ALPHA_APP ->
                    searched.sortedWith(compareByDescending<ClipboardItem> { it.isPinned }
                        .thenBy { (it.appName ?: "").lowercase() })
                SortOrder.TYPE      ->
                    searched.sortedWith(compareByDescending<ClipboardItem> { it.isPinned }
                        .thenBy { it.mimeType ?: "text/plain" }
                        .thenByDescending { it.timestamp })
            }
        }.asLiveData()
    }

    // ── Expansion ────────────────────────────────────────────────────────────

    fun toggleExpand(itemId: Int) {
        val current = _expandedIds.value
        _expandedIds.value = if (current.contains(itemId)) current - itemId else current + itemId
    }

    // ── Selection (in-memory, zero DB cost) ─────────────────────────────────

    fun toggleSelection(item: ClipboardItem) {
        val current = _selectedIds.value
        _selectedIds.value = if (current.contains(item.id)) current - item.id else current + item.id
        _isSelectionMode.value = _selectedIds.value.isNotEmpty()
    }

    fun clearSelection() {
        _selectedIds.value = emptySet()
        _isSelectionMode.value = false
    }

    // ── Pin ──────────────────────────────────────────────────────────────────

    fun togglePin(item: ClipboardItem) = viewModelScope.launch(Dispatchers.IO) {
        repository.update(item.copy(isPinned = !item.isPinned))
    }

    fun togglePinSelectedClips() = viewModelScope.launch {
        val ids = _selectedIds.value
        if (ids.isEmpty()) return@launch
        val selectedItems = cachedClips.filter { ids.contains(it.id) }
        if (selectedItems.isEmpty()) return@launch
        val allPinned = selectedItems.all { it.isPinned }
    
        withContext(Dispatchers.IO) {
            selectedItems.forEach { repository.update(it.copy(isPinned = !allPinned)) }
        }
        _selectedIds.value = emptySet()
        _isSelectionMode.value = false
    }
    // ── New column toggles ───────────────────────────────────────────────────

    fun toggleFavorite(item: ClipboardItem) = viewModelScope.launch(Dispatchers.IO) {
        repository.toggleFavorite(item)
    }

    fun toggleSensitive(item: ClipboardItem) = viewModelScope.launch(Dispatchers.IO) {
        repository.toggleSensitive(item)
    }

    fun updateLabel(item: ClipboardItem, label: String?) = viewModelScope.launch(Dispatchers.IO) {
        repository.updateLabel(item.id, label)
    }

    // ── Insert ───────────────────────────────────────────────────────────────

    fun insert(clip: String) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(
            ClipboardItem(
                clip        = clip,
                appName     = "Manual Entry",
                packageName = "nocom.rian.clipboardmanager",
                timestamp   = System.currentTimeMillis()
            )
        )
    }
    
    fun updateClipById(
        itemId: Int,
        newClip: String?,
        newLabel: String?,
        newAppName: String?,
        newPackageName: String?,
        newWindowLabel: String?,
        newActivityName: String?
    ) = viewModelScope.launch(Dispatchers.IO) {
        val item = cachedClips.find { it.id == itemId } ?: return@launch
        repository.update(
            item.copy(
                clip         = if (item.mimeType?.startsWith("image/") == true) item.clip else newClip,
                label        = newLabel,
                appName      = newAppName,
                packageName  = newPackageName,
                windowLabel  = newWindowLabel,
                activityName = newActivityName
            )
        )
    }
    
    // ── Delete ───────────────────────────────────────────────────────────────

    private fun deleteImageFileIfNeeded(item: ClipboardItem) {
        if (item.mimeType?.startsWith("image/") == true) {
            val file = java.io.File(item.filePath ?: return)
            if (file.exists()) {
                android.util.Log.d("ClipboardViewModel", "Image deleted: ${item.filePath}")
                file.delete()
            }
        }
    }

    fun delete(item: ClipboardItem) = viewModelScope.launch(Dispatchers.IO) {
        deleteImageFileIfNeeded(item)
        repository.delete(item)
    }

    fun deleteAllUnpinned() = viewModelScope.launch(Dispatchers.IO) {
        repository.getUnpinnedItems().forEach { deleteImageFileIfNeeded(it) }
        repository.clearUnpinned()
    }

    fun deleteSelectedClips() = viewModelScope.launch {
        val ids = _selectedIds.value
        if (ids.isEmpty()) return@launch
        val selectedItems = cachedClips.filter { ids.contains(it.id) }
    
        withContext(Dispatchers.IO) {
            selectedItems.forEach { item ->
                deleteImageFileIfNeeded(item)
                repository.delete(item)
            }
        }
        _selectedIds.value = emptySet()
        _isSelectionMode.value = false
    }

    // ── Clipboard copy ───────────────────────────────────────────────────────

    fun copyToClipboard(context: android.content.Context, item: ClipboardItem) {
        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                as android.content.ClipboardManager

        if (item.mimeType?.startsWith("image/") == true) {
            val file = java.io.File(item.filePath ?: return)
            if (!file.exists()) {
                android.util.Log.e("ClipboardViewModel", "Image missing: ${item.filePath}")
                return
            }
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", file
            )
            clipboard.setPrimaryClip(
                android.content.ClipData.newUri(context.contentResolver, "Copied Image", uri)
            )
        } else {
            clipboard.setPrimaryClip(
                android.content.ClipData.newPlainText("Copied Clip", item.clip)
            )
        }
    }
}