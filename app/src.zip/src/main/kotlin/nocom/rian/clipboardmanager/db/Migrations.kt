package nocom.rian.clipboardmanager.db

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_3_4 = object : Migration(3, 4) {

    override fun migrate(db: SupportSQLiteDatabase) {

        db.execSQL("""
            ALTER TABLE clipboardmanager
            ADD COLUMN window_label TEXT
        """.trimIndent())
    
        db.execSQL("""
            ALTER TABLE clipboardmanager
            ADD COLUMN activity_name TEXT
        """.trimIndent())
    }
}