package nocom.rian.clipboardmanager

import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import nocom.rian.clipboardmanager.databinding.ActivitySettingsBinding
import nocom.rian.clipboardmanager.db.AppDatabase
import nocom.rian.clipboardmanager.db.BackupManager
import nocom.rian.clipboardmanager.db.ClipboardRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.io.File
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: SharedPreferences

    // ── SAF launchers ─────────────────────────────────────────────────────────

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? ->
        if (uri != null) performExport(uri)
    }
    
    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) performImport(uri)
    }
    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
    
        setSupportActionBar(binding.settingsToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        loadCurrentValues()
        setupSliderListeners()
        setupBackupButtons()
        setupDisplayFieldToggles()
        setupLoggingFieldToggles()
        setupExcludedApps()
    }
    
    // ── UI setup ──────────────────────────────────────────────────────────────

    private fun loadCurrentValues() {
        val days = prefs.getInt(KEY_AUTO_DELETE_DAYS, 0)
        binding.sliderAutoDelete.value = days.toFloat()
        binding.tvAutoDeleteValue.text = formatDays(days)
    
        val cap = prefs.getInt(KEY_CLIP_CAP, 0)
        binding.sliderClipCap.value = cap.toFloat()
        binding.tvClipCapValue.text = formatCap(cap)
        
        val monitoringEnabled = prefs.getBoolean(KEY_MONITORING_ENABLED,true)
        binding.switchMonitoring.isChecked = monitoringEnabled
        updateMonitoringStatusText(monitoringEnabled)

        binding.switchManualEntry.isChecked = prefs.getBoolean(KEY_SHOW_MANUAL_ENTRY, true)
    
        // Display toggles — all on by default
        binding.switchShowAppName.isChecked = prefs.getBoolean(KEY_SHOW_FIELD_APP_NAME, true)
        binding.switchShowPackage.isChecked  = prefs.getBoolean(KEY_SHOW_FIELD_PACKAGE, true)
        binding.switchShowWindow.isChecked   = prefs.getBoolean(KEY_SHOW_FIELD_WINDOW, true)
        binding.switchShowActivity.isChecked = prefs.getBoolean(KEY_SHOW_FIELD_ACTIVITY, true)
        binding.switchShowLabel.isChecked    = prefs.getBoolean(KEY_SHOW_FIELD_LABEL, true)
        binding.switchShowTech.isChecked     = prefs.getBoolean(KEY_SHOW_FIELD_TECH, true)
    
        // Logging toggles — all on by default
        binding.switchLogAppName.isChecked = prefs.getBoolean(KEY_LOG_FIELD_APP_NAME, true)
        binding.switchLogPackage.isChecked  = prefs.getBoolean(KEY_LOG_FIELD_PACKAGE, true)
        binding.switchLogWindow.isChecked   = prefs.getBoolean(KEY_LOG_FIELD_WINDOW, true)
        binding.switchLogActivity.isChecked = prefs.getBoolean(KEY_LOG_FIELD_ACTIVITY, true)
    }
    
    private fun updateMonitoringStatusText(enabled: Boolean) {
        binding.tvMonitoringStatus.text = if (enabled)
            "Active — capturing clipboard changes"
        else
            "Paused — service is stopped"
    }
    
    private fun setupSliderListeners() {
    
        binding.switchMonitoring.setOnCheckedChangeListener { buttonView, isChecked ->
            // 1. Prevent Android's view state restoration from triggering this programmatically
            if (!buttonView.isPressed) return@setOnCheckedChangeListener
        
            // 2. Use .commit() to write to disk instantly before the app can be killed
            prefs.edit().putBoolean(KEY_MONITORING_ENABLED, isChecked).commit()
            
            updateMonitoringStatusText(isChecked)
            
            val intent = Intent(this, nocom.rian.clipboardmanager.service.ClipboardService::class.java)
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intent)
                } else {
                    startService(intent)
                }
            } else {
                stopService(intent)
            }
        }

        binding.sliderAutoDelete.addOnChangeListener { _, value, _ ->
            val days = value.toInt()
            prefs.edit().putInt(KEY_AUTO_DELETE_DAYS, days).apply()
            binding.tvAutoDeleteValue.text = formatDays(days)
        }

        binding.sliderClipCap.addOnChangeListener { _, value, _ ->
            val cap = value.toInt()
            prefs.edit().putInt(KEY_CLIP_CAP, cap).apply()
            binding.tvClipCapValue.text = formatCap(cap)
        }

        binding.switchManualEntry.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(KEY_SHOW_MANUAL_ENTRY, isChecked).apply()
        }
    }

    private fun setupBackupButtons() {
        binding.btnExport.setOnClickListener {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            exportLauncher.launch("clipboard_backup_$timestamp.zip")
        }
    
        binding.btnImport.setOnClickListener {
            importLauncher.launch(arrayOf("application/zip", "application/octet-stream"))
        }
    
        binding.btnWipeDatabase.setOnClickListener {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Wipe All Data?")
                .setMessage("This will permanently delete every clip and saved image. Export a backup first if you want to keep your history.")
                .setPositiveButton("Wipe Everything") { _, _ -> performWipe() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
    
    private fun setupDisplayFieldToggles() {
        binding.switchShowAppName.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_SHOW_FIELD_APP_NAME, checked).apply()
        }
        binding.switchShowPackage.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_SHOW_FIELD_PACKAGE, checked).apply()
        }
        binding.switchShowWindow.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_SHOW_FIELD_WINDOW, checked).apply()
        }
        binding.switchShowActivity.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_SHOW_FIELD_ACTIVITY, checked).apply()
        }
        binding.switchShowLabel.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_SHOW_FIELD_LABEL, checked).apply()
        }
        binding.switchShowTech.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_SHOW_FIELD_TECH, checked).apply()
        }
    }
    
    private fun setupLoggingFieldToggles() {
        binding.switchLogAppName.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_LOG_FIELD_APP_NAME, checked).apply()
        }
        binding.switchLogPackage.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_LOG_FIELD_PACKAGE, checked).apply()
        }
        binding.switchLogWindow.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_LOG_FIELD_WINDOW, checked).apply()
        }
        binding.switchLogActivity.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_LOG_FIELD_ACTIVITY, checked).apply()
        }
    }
    
    
    private fun setupExcludedApps() {
        updateExcludedAppsCount()
        binding.btnManageExcludedApps.setOnClickListener {
            showAppPickerDialog()
        }
    }
    
    private fun updateExcludedAppsCount() {
        val excluded = loadExcludedPackages()
        binding.tvExcludedAppsCount.text = if (excluded.isEmpty())
            "No apps excluded"
        else
            "${excluded.size} app${if (excluded.size == 1) "" else "s"} excluded"
    }
    
    private fun loadExcludedPackages(): Set<String> {
        val json = prefs.getString(KEY_EXCLUDED_PACKAGES, null) ?: return emptySet()
        return try {
            val array = org.json.JSONArray(json)
            buildSet { for (i in 0 until array.length()) add(array.getString(i)) }
        } catch (e: Exception) {
            emptySet()
        }
    }
    
    private fun saveExcludedPackages(packages: Set<String>) {
        val json = org.json.JSONArray(packages.toList()).toString()
        prefs.edit().putString(KEY_EXCLUDED_PACKAGES, json).apply()
    }
        
    private fun showAppPickerDialog() {
        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
            .map { ri -> Pair(ri.loadLabel(pm).toString(), ri.activityInfo.packageName) }
            .distinctBy { it.second }
            .filter { it.second != packageName }
            .sortedBy { it.first.lowercase() }
    
        if (apps.isEmpty()) {
            Toast.makeText(this, "No apps found", Toast.LENGTH_SHORT).show()
            return
        }
    
        val excluded = loadExcludedPackages().toMutableSet()
        val checked = BooleanArray(apps.size) { excluded.contains(apps[it].second) }
        val labels = apps.map { it.first }.toTypedArray()
    
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Exclude Apps")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Save") { _, _ ->
                val newExcluded = apps.indices
                    .filter { checked[it] }
                    .map { apps[it].second }
                    .toSet()
                saveExcludedPackages(newExcluded)
                updateExcludedAppsCount()
            }
            .setNeutralButton("Clear All") { _, _ ->
                saveExcludedPackages(emptySet())
                updateExcludedAppsCount()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    // ── Export ────────────────────────────────────────────────────────────────

    private fun performExport(uri: Uri) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val clips = AppDatabase.getDatabase(applicationContext)
                        .clipboardDao()
                        .getAllClipsOnce()
    
                    contentResolver.openOutputStream(uri)?.use { stream ->
                        BackupManager.exportZip(clips, stream)
                    } ?: Result.failure(Exception("Could not open output stream"))
    
                } catch (e: Exception) {
                    Result.failure(e)
                }
            }
    
            result.fold(
                onSuccess = { count ->
                    Snackbar.make(
                        binding.root,
                        "Exported $count clip${if (count == 1) "" else "s"} to ZIP",
                        Snackbar.LENGTH_LONG
                    ).show()
                },
                onFailure = { e ->
                    Snackbar.make(
                        binding.root,
                        "Export failed: ${e.message}",
                        Snackbar.LENGTH_LONG
                    ).show()
                }
            )
        }
    }
    // ── Import ───────────────────────────────────────────────────────────────

    private fun performImport(uri: Uri) {
        // Confirm before overwriting anything
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Import Clips")
            .setMessage("Imported clips will be added alongside your existing history. Duplicates may appear. Continue?")
            .setPositiveButton("Import") { _, _ -> doImport(uri) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doImport(uri: Uri) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val imageDir = File(
                        getExternalFilesDir(null), "clipboard_images"
                    )
    
                    val clips = contentResolver.openInputStream(uri)?.use { stream ->
                        BackupManager.importZip(stream, imageDir)
                    } ?: Result.failure(Exception("Could not open file"))
    
                    clips.map { list ->
                        val dao = AppDatabase.getDatabase(applicationContext).clipboardDao()
                        val repo = ClipboardRepository(dao)
                        // Insert oldest first so Room assigns lower IDs to older clips,
                        // matching the expected newest = highest ID ordering.
                        list.sortedBy { it.timestamp }.forEach { repo.insert(it) }
                        list.size
                    }
                } catch (e: Exception) {
                    Result.failure(e)
                }
            }
    
            result.fold(
                onSuccess = { count ->
                    Snackbar.make(
                        binding.root,
                        "Imported $count clip${if (count == 1) "" else "s"} successfully",
                        Snackbar.LENGTH_LONG
                    ).show()
                },
                onFailure = { e ->
                    Snackbar.make(
                        binding.root,
                        "Import failed: ${e.message}",
                        Snackbar.LENGTH_LONG
                    ).show()
                }
            )
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    
    private fun performWipe() {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    // 1. Delete all image files
                    val imageDir = File(getExternalFilesDir(null), "clipboard_images")
                    imageDir.listFiles()?.forEach { it.delete() }
    
                    // 2. Clear the database table
                    val dao = AppDatabase.getDatabase(applicationContext).clipboardDao()
                    dao.clearUnpinnedHistory()
                    // clearUnpinnedHistory only removes unpinned — wipe everything:
                    AppDatabase.getDatabase(applicationContext)
                        .clipboardDao()
                        .deleteAll()
                } catch (e: Exception) {
                    android.util.Log.e("SettingsActivity", "Wipe failed", e)
                }
            }
            Snackbar.make(binding.root, "All clipboard data wiped.", Snackbar.LENGTH_LONG).show()
        }
    }

    private fun formatDays(days: Int) = if (days == 0) "Disabled" else "$days days"
    private fun formatCap(cap: Int)  = if (cap  == 0) "Unlimited" else "$cap clips"

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    companion object {
        const val PREFS_NAME             = "clipboard_settings"
        const val KEY_AUTO_DELETE_DAYS   = "auto_delete_days"
        const val KEY_CLIP_CAP           = "clip_cap"
        const val KEY_SHOW_MANUAL_ENTRY  = "show_manual_entry"
        const val KEY_MONITORING_ENABLED = "monitoring_enabled" 
        const val KEY_EXCLUDED_PACKAGES  = "excluded_packages"
        
        // Display field toggles (expanded clip view)
        const val KEY_SHOW_FIELD_APP_NAME = "show_field_app_name"
        const val KEY_SHOW_FIELD_PACKAGE  = "show_field_package"
        const val KEY_SHOW_FIELD_WINDOW   = "show_field_window"
        const val KEY_SHOW_FIELD_ACTIVITY = "show_field_activity"
        const val KEY_SHOW_FIELD_LABEL    = "show_field_label"
        const val KEY_SHOW_FIELD_TECH     = "show_field_tech"
    
        // Logging field toggles (what gets written to DB)
        const val KEY_LOG_FIELD_APP_NAME = "log_field_app_name"
        const val KEY_LOG_FIELD_PACKAGE  = "log_field_package"
        const val KEY_LOG_FIELD_WINDOW   = "log_field_window"
        const val KEY_LOG_FIELD_ACTIVITY = "log_field_activity"
    }
}